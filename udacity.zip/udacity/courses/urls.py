from django.urls import path
from .views import DetailListView, dataView, dataCreate, dataUpdate

# <app>/<moddel>_<typeview>.html

urlpatterns = [
    path("", DetailListView.as_view(), name = 'detail-list'),
    path("detail/<int:pk>", dataView.as_view(), name = 'view_detail'),
    path("detail/new", dataCreate.as_view(), name = 'create'),
    path("detail/update/<int:pk>", dataUpdate.as_view(), name = 'update'),


]
